# KMeans Clustering in CUDA

The objective is to implement KMeans algorithm in CUDA.
